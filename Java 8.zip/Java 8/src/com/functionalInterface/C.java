package com.functionalInterface;

@FunctionalInterface
public interface C extends P{//should have only one abstract method

//	public void m4();//Parent already has one method
}
