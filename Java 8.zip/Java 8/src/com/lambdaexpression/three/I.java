package com.lambdaexpression.three;

@FunctionalInterface
public interface I {
	public int getLength(String s);
}
