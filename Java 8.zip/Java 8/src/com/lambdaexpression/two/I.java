package com.lambdaexpression.two;

@FunctionalInterface
public interface I {
	public int add(int a, int b);
}
