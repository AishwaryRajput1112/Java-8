package com.lambdaexpression.one;

public class Test {

	public static void main(String[] args) {
		
		I i = ()->System.out.println("Hi");
		i.m1();
	}
}
