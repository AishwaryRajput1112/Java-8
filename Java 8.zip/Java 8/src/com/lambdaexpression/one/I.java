package com.lambdaexpression.one;

@FunctionalInterface
public interface I {
	public void m1();
}
