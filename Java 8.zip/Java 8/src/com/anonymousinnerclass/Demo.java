package com.anonymousinnerclass;

public class Demo implements I{

	@Override
	public void m() {
		// TODO Auto-generated method stub
		
	}

}
