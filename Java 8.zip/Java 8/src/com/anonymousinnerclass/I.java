package com.anonymousinnerclass;

public interface I {
	public void m();
}
