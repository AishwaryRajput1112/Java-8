package com.staticmethods.inside.interfac;

public interface I1 {

	static int addNumbers(int x, int y) {
		return x+y;
	}
	
}
