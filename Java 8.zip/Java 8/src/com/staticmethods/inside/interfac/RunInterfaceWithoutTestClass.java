package com.staticmethods.inside.interfac;

public interface RunInterfaceWithoutTestClass {

	public static void main(String[] args) {
		
		System.out.println("Har Har Mahadev ");
		
	}
}
