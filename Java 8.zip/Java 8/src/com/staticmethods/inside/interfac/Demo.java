package com.staticmethods.inside.interfac;

public class Demo implements I1{

	public static void main(String[] args) {
		System.out.println(I1.addNumbers(10, 20));
	}
}
