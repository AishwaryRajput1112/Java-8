package com.defaultmethods;

public interface I1 {

	default void m() {
		System.out.println("Hiiii---I1");
	}
}
