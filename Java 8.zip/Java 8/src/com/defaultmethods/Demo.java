package com.defaultmethods;

public class Demo implements I1,I2 {

//	@Override
//	public void m() {
//		
//	}
	
	// Or
	
	@Override
	public void m() {
	//	I2.super.m();
	//	I1.super.m();
	}

}
