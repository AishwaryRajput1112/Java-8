package com.invoke.lambda;

@FunctionalInterface
public interface I {
	public int x(int a );
}
