package com.invoke.lambda;

public class Demo implements I{

	@Override
	public int x(int a) {
		// TODO Auto-generated method stub
		return a*a;
	}

}
