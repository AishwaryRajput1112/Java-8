package com.method.references;

public interface Interf {

	public void m();
}
