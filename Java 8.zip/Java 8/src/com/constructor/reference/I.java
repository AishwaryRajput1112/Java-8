package com.constructor.reference;

public interface I {

	public Sample m();
}
