package com.bifunction;

public class Student {

	private int id;
	private String name;
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	};
	
}
